"""Source adapters for PaperCompass."""
